# Import QRCode from pyqrcode
import pyqrcode
import png
from pyqrcode import QRCode
  
  
# String which represents the QR code
# s = "www.geeksforgeeks.org"
s = "https://docs.google.com/spreadsheets/d/1H5q3rGbRQui6dokkiXa5KtY16nAiNu_ItfpPnitU1jQ/edit?usp=sharing"
  
# Generate QR code
url = pyqrcode.create(s)
  
# Create and save the svg file naming "myqr.svg"
url.svg("Report.svg", scale = 8)
  
# Create and save the png file naming "myqr.png"
url.png('Report.png', scale = 6)