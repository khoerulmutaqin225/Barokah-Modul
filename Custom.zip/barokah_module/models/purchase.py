# -- coding: utf-8 -- tofu
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError
from datetime import datetime
from datetime import timedelta
from odoo.tools.float_utils import float_compare, float_round
from dateutil import relativedelta

STATUS = [('onprogress', 'On Progress'),
          ('hold', 'Hold'),
          ('cancel', 'Cancel'),
          ('close', 'Close')]

STATUS_KETERANGAN = [('ready', 'Ready'), ('indent', 'Indent'), ('konfirmasi', 'Konfirmasi'),
                     ('delivery', 'Delivery')
                     ]


class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    _description ='product.template'
    
    def name_get(self):
        # Prefetch the fields used by the `name_get`, so `browse` doesn't fetch other fields
        x = self.browse(self.ids).read(['name', 'default_code'])
        for rec in self:
            uom_name = rec.uom_name
            uom_id = rec.uom_id
            measure_type = rec.uom_id.measure_type
            uom_type = rec.uom_id.uom_type
        data= []
        for template in self:
            y = (template.id, '%s%s%s%s%s%s%s%s' % (template.default_code and '[%s] ' % template.default_code or '', template.name," ","-"," ","(",template.uom_name,")"))
            data.append(y)
        return data    


class PurchaseOrderLineAdded(models.Model):
    _inherit = 'purchase.order.line'
    
    

    tipe_pesanan = fields.Selection(
        string='Tipe Pesanan',
         selection = [('ug', 'UG (Urgent)'), ('tv', 'TV (Temuan Vetting)'),
                      ('rp', 'Repair (RP)'),('nb','NB (New Building)'),('op','OP (Operasional)'),('dk','DK (Docking)')]
    )

    # code_company = fields.Char(
    #     related='company_id.code_company',
    #     string='Code Company',
    #     required=False)
    
    code_company = fields.Char('code_company')


    arrival_estimation = fields.Integer(
        string='Days',
    )

    request_accepted_date = fields.Datetime(
        string="Request Accepted Date",
    )

    date_start = fields.Date(
        string="Creation Date",
    )

    origin = fields.Char(
        string="Nomor Request",
    )

    status_list = fields.Selection(
        string='Status Type',
        selection=STATUS,
    )

    keterangan_status = fields.Selection(selection=STATUS_KETERANGAN,
                                         string="Keterangan Status")

    remark = fields.Char(
        string='Remark',
    )

    # project_id = fields.Many2one(
    #     'project.unit',
    #     string='Project / Unit',
    #     ondelete='restrict',
    # )

    project_id = fields.Char('project_id')
    
    # divisi_id = fields.Many2one(
    #     string='Divisi',
    #     comodel_name='hr.department',
    #     ondelete='restrict',
    #     track_visibility='onchange',
    # )
    
    divisi_id = fields.Char('divisi_id')

    requested_by = fields.Many2one(
        comodel_name="res.users",
        string="Requested by",
    )

    # code_budget_id = fields.Many2one(
    #     comodel_name="code.budget",
    #     string="Code Budget",
    #     readonly=False,
    # )
    code_budget_id = fields.Char('code_budget_id')
    
    priority = fields.Selection(
        string='Priority',
        selection=[('high', 'H'), ('medium', 'M'), ('low', 'L')]
    )
    # lokasi_id = fields.Many2one(
    #     comodel_name='lokasi.lokasi',
    #     string='Lokasi Supply',
    # )
    lokasi_id = fields.Char('lokasi_id')
    
    # @api.depends('product_id.merk','product_id.model_barang','product_id.nomor_seri')
    # def _get_specs_product(self):
    #     for rec in self:
    #         specification:''
    #         if rec.product_id:
    #             if (rec.product_id.merk == False) and (rec.product_id.model_barang == False) and (rec.product_id.nomor_seri == False):
    #                 specification = ''
    #             elif (rec.product_id.merk != False) and (rec.product_id.model_barang != False) and (rec.product_id.nomor_seri != False):
    #                 specification = rec.product_id.merk + ' ' + rec.product_id.model_barang + ' ' + rec.product_id.nomor_seri
    #             elif (rec.product_id.merk != False and rec.product_id.model_barang != False) and (rec.product_id.nomor_seri == False):
    #                 specification = rec.product_id.merk + ' ' + rec.product_id.model_barang
    #             elif (rec.product_id.merk != False and rec.product_id.nomor_seri != False) and (rec.product_id.model_barang == False):
    #                 specification = rec.product_id.merk + ' ' + rec.product_id.nomor_seri
    #             elif (rec.product_id.model_barang != False and rec.product_id.nomor_seri != False) and (rec.product_id.merk == False):
    #                 specification = rec.product_id.model_barang + ' ' + rec.product_id.nomor_seri
    #             elif (rec.product_id.merk != False):
    #                 specification = rec.product_id.merk
    #             elif (rec.product_id.model_barang != False):
    #                 specification = rec.product_id.model_barang
    #             elif (rec.product_id.nomor_seri != False):
    #                 specification = rec.product_id.nomor_seri
    #             rec.update({'specs': specification})


    # specs = fields.Text(string="Specifications", readonly=True,compute='_get_specs_product')
    specs = fields.Char('specs')

    merk_barang = fields.Char(
        string='Merk (Tipe)',
    )

    model_barang = fields.Char(
        string='Model Barang',
    )

    nomor_seri = fields.Char(
        string='No. Seri',
    )

    # vessel_id = fields.Many2one(
    #     comodel_name='shipping.vessel', string='Vessel',
    # )
    
    vessel_id = fields.Char('vessel_id')

    form_type = fields.Selection(
        ondelete='restrict',
        selection=[('darat', 'Darat'), ('kapal', 'Kapal')],
        string="Tipe Form",
    )

    picking_type_id = fields.Many2one(
        'stock.picking.type',
        string="Picking Type",
    )

    
    # is_sb = fields.Boolean(
    #     string='SB',compute='_compute_sb'
    #     )
    
    is_sb = fields.Boolean(
        string='SB')
        
    
    # @api.onchange('order_id.sbkah')
    # def _compute_sb(self):
    #     check = self.order_id.sbkah
    #     for rec in self:
    #         rec.is_sb = check
    
        
    price_unit = fields.Monetary(string='Unit Price', required=True, digits='Product Price')

    @api.depends('product_id.name')
    def _get_description_product(self):
        for rec in self:
            name_product: ''
            if rec.product_id:
                name_product = rec.product_id.name
                rec.update({'name_product': name_product})

    name_product = fields.Char(string="Description",readonly=True,compute='_get_description_product',)

    product_uom_id = fields.Many2one(
        comodel_name="uom.uom",
        string="UoM",
        track_visibility="onchange",
    )
def _prepare_stock_moves(self, picking):
        """ Prepare the stock moves data for one order line. This function returns a list of
        dictionary ready to be used in stock.move's create()
        """
        self.ensure_one()
        res = []
        if self.product_id.type not in ['product', 'consu']:
            return res
        qty = 0.0
        price_unit = self._get_stock_move_price_unit()
        outgoing_moves, incoming_moves = self._get_outgoing_incoming_moves()
        for move in outgoing_moves:
            qty -= move.product_uom._compute_quantity(move.product_uom_qty, self.product_uom, rounding_method='HALF-UP')
        for move in incoming_moves:
            qty += move.product_uom._compute_quantity(move.product_uom_qty, self.product_uom, rounding_method='HALF-UP')
        description_picking = self.product_id.with_context(
            lang=self.order_id.dest_address_id.lang or self.env.user.lang)._get_description(
            self.order_id.picking_type_id)
        template = {
            # truncate to 2000 to avoid triggering index limit error
            # TODO: remove index in master?
            'name': (self.name or '')[:2000],
            'product_id': self.product_id.id,
            'product_uom': self.product_uom.id,
            'date': self.order_id.date_order,
            'date_expected': self.date_planned,
            'location_id': self.order_id.partner_id.property_stock_supplier.id,
            'location_dest_id': self.order_id._get_destination_location(),
            'picking_id': picking.id,
            'partner_id': self.order_id.dest_address_id.id,
            'move_dest_ids': [(4, x) for x in self.move_dest_ids.ids],
            'state': 'draft',
            'purchase_line_id': self.id,
            'company_id': self.order_id.company_id.id,
            'price_unit': price_unit,
            'picking_type_id': self.order_id.picking_type_id.id,
            'group_id': self.order_id.group_id.id,
            'origin': self.order_id.name,
            'propagate_date': self.propagate_date,
            'propagate_date_minimum_delta': self.propagate_date_minimum_delta,
            'description_picking': description_picking,
            'propagate_cancel': self.propagate_cancel,
            'route_ids': self.order_id.picking_type_id.warehouse_id and [
                (6, 0, [x.id for x in self.order_id.picking_type_id.warehouse_id.route_ids])] or [],
            'warehouse_id': self.order_id.picking_type_id.warehouse_id.id,
            # tambahan
            'name_product': self.name_product,
            'lokasi_id': self.lokasi_id.id,
            'requested_by': self.requested_by.id,
            'date_start': self.date_start,
            'nomor_request': self.origin,
            'request_accepted_date': self.request_accepted_date,
            'vessel_id': self.vessel_id.id,
            'divisi_id': self.divisi_id.id,
            'code_budget_id': self.code_budget_id.id,
            'specs': self.specs,
            'priority_request': self.priority,
            'arrival_estimation': self.arrival_estimation,
            'status_list': self.status_list,
            'keterangan_status': self.keterangan_status,
            'remark': self.remark,
            "project_id": self.project_id.id,
            'vendor_id': self.partner_id.id,
            'code_company': self.code_company,
        }
        diff_quantity = self.product_qty - qty
        if float_compare(diff_quantity, 0.0, precision_rounding=self.product_uom.rounding) > 0:
            po_line_uom = self.product_uom
            quant_uom = self.product_id.uom_id
            product_uom_qty, product_uom = po_line_uom._adjust_uom_quantities(diff_quantity, quant_uom)
            template['product_uom_qty'] = product_uom_qty
            template['product_uom'] = product_uom.id
            res.append(template)
        return res
