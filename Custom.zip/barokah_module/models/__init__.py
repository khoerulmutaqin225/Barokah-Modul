# -*- coding: utf-8 -*-

from . import stock_picking_inherit
from . import res_user_inherit
from . import purchase