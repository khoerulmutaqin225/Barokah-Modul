Allows to define a specific destination location on each Purchase Order line.
When the PO is confirmed, it will generate one Incoming Shipment per
combination of destination location and expected date indicated in the
Purchase Order Lines.

This module is used to send the products to different locations, that may
not be children of the default location of the same PO picking type. Not be confused.
